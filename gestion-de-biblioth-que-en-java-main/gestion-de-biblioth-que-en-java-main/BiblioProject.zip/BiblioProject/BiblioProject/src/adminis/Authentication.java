package adminis;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import conn.Connec;

import java.sql.*;
public class Authentication extends JFrame implements ActionListener {
    JLabel lb1, lb2, lb3, lb4, lb5, lbtitre;
    JTextField tf1, tf2, tf3, tf4, tf5;
    JButton bt1, bt2, bt3, bt4, bt5, bt6, blivre, bpret;
    ResultSet rst;
    Statement st;
    Connec cn = new Connec();
    JTable jt;
    JScrollPane js;
    private JTextField usernameField;
    private JPasswordField passwordField;

    public Authentication() {
        this.setTitle("Authentification");
        this.setSize(350, 320);
        this.setLocationRelativeTo(null);
        JPanel pn = new JPanel();
        pn.setLayout(null);
        pn.setBackground(new Color(189, 189, 189));
        add(pn);
        
        lb1 = new JLabel("Authentification");
        lb1.setBounds(80, 50, 200, 30);
        lb1.setFont(new Font("Arial", Font.BOLD, 20));
        lb1.setForeground(Color.BLUE);
        pn.add(lb1);

        JLabel lblUsername = new JLabel("Nom d'utilisateur:");
        lblUsername.setBounds(50, 130, 100, 20);
        pn.add(lblUsername);

        JLabel lblPassword = new JLabel("Mot de passe:");
        lblPassword.setBounds(50, 170, 100, 20);
        pn.add(lblPassword);

        usernameField = new JTextField();
        usernameField.setBounds(160, 130, 100, 20);
        pn.add(usernameField);

        passwordField = new JPasswordField();
        passwordField.setBounds(160, 170, 100, 20);
        pn.add(passwordField);

        JButton btnLogin = new JButton("Se connecter");
        btnLogin.setBounds(120, 210, 150, 30);
        pn.add(btnLogin);

        btnLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                if (authenticate(username, password)) {
                    Abonne abonne = new Abonne();
                    abonne.setVisible(true);
                } else {
                    UIManager.put("OptionPane.messageForeground", Color.RED);
                    JOptionPane.showMessageDialog(
                        Authentication.this,
                        "<html><font color='red'>Nom d'utilisateur ou mot de passe incorrect !</font></html>"
                    );
                }
            }
        });

        setVisible(true);
    }

    private boolean authenticate(String username, String password) {
        return username.equals("ISI") && password.equals("2023");
    }

    public static void main(String[] args) {
        Authentication rq = new Authentication();
        rq.setVisible(true);
    }

        	@Override
        	public void actionPerformed(ActionEvent e) {
        	    if (e.getSource() == bt1) {
        	        String id = tf1.getText();
        	        String mdp = tf2.getText();
        	        if (id.equals("ISI") && mdp.equals("2023")) {
        	            dispose();
        	            Authentication lv = new Authentication();
        	            lv.setVisible(true);
        	        } else {
        	            JOptionPane.showMessageDialog(this, "Erreur,Identifiant / Mot de passe incorrect!", null, JOptionPane.ERROR_MESSAGE);
        	        }
        	    }
        	}
}